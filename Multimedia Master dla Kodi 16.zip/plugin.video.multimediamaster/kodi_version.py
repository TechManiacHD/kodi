import json
import xbmc


def get_version():
    json_data = {
        'id': 1,
        'jsonrpc': '2.0',
        'method': 'JSONRPC.Version',
    }

    response = xbmc.executeJSONRPC(json.dumps(json_data))

    try:
        data = json.loads(response)
        version_data = data['result']['version']
        major = int(version_data['major'])
        minor = int(version_data['minor'])
    except Exception as ex:
        print('Error while getting version info: {0}'.format(ex))
        major, minor = 0, 0

    if major == 8:
        return 17

    if major == 6:
        if minor == 32:
            return 16
        elif minor == 25:
            return 15

    return -1

KODI_VERSION = get_version()
