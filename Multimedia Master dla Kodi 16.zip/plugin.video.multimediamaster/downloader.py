from __future__ import print_function
import xbmc
import xbmcgui
import requests
import socket
import time

TIMEOUT = 10
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

socket.setdefaulttimeout(TIMEOUT)


def download(url, dest, dp=None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create("SimpleKodi...Maintenance", "Downloading & Copying File", ' ', ' ')
    dp.update(0)

    headers = {'User-Agent': USER_AGENT, 'Accept': '*/*', 'Accept-Encoding': 'identity'}

    downloaded = 0
    total_size = 0
    max_attempts = 30

    previous_percent = 0

    xbmc.log('[downloader] Download {0!r} to {1!r}'.format(url, dest), xbmc.LOGNOTICE)
    with open(dest, 'wb') as f:
        for attempt in range(1, max_attempts + 1):
            try:
                # If something is already downloaded, then we must provide
                # a "Range" header to the server.
                if downloaded != 0:
                    h = {'Range': 'bytes={0}-'.format(downloaded)}
                    headers.update(h)

                # Create a request with chosen settings.
                r = requests.get(url, stream=True, timeout=(TIMEOUT, TIMEOUT), headers=headers)

                # Content-Length shows the total download size ONLY if it's the first attempt.
                if not total_size:
                    total_size = int(r.headers.get('content-length'))

                # Iterate over received data, update the progress and write it to file.
                for chunk in r.iter_content(chunk_size=256 * 1024):
                    if not chunk:
                        continue

                    f.write(chunk)
                    downloaded += len(chunk)
                    percent = int(downloaded * 100.0 / total_size)
                    if previous_percent != percent:
                        previous_percent = percent
                        if percent % 10 == 0:
                            xbmc.log('[downloader] Downloaded {0}% so far...'.format(percent), xbmc.LOGNOTICE)
                        update_progressbar(percent, dp)

                # Everything is finished!
                if downloaded == total_size:
                    break
            except requests.exceptions.ConnectionError:
                xbmc.log('[downloader] [attempt #{0}] Connection error, retrying...'.format(attempt), xbmc.LOGNOTICE)
            except requests.exceptions.ChunkedEncodingError:
                xbmc.log('[downloader] [attempt #{0}] Got malformed data, retrying...'.format(attempt), xbmc.LOGNOTICE)
            except socket.timeout:
                xbmc.log('[downloader] [attempt #{0}] Socket timeout, retrying...'.format(attempt), xbmc.LOGNOTICE)

            sleep_time = attempt / 5 + 1
            time.sleep(sleep_time)
        else:
            xbmc.log('[downloader] Could not download the file after {0} attempts!'.format(max_attempts), xbmc.LOGERROR)
            raise Exception('Download unsuccessful!')

    xbmc.log('[downloader] Download finished! {0:.2f}%, {1} bytes downloaded'.format(
        downloaded * 100.0 / total_size, downloaded,
    ), xbmc.LOGNOTICE)


def update_progressbar(percent, dp):
    dp.update(percent)

    if dp.iscanceled():
        dp.close()
        raise Exception("Canceled")

