# coding: utf-8
import json
import os
import shutil
import socket
import sys
import time
from collections import defaultdict
from urllib import quote_plus
from urlparse import parse_qsl

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import downloader
import extract
from kodi_version import _KODI_VERSION
from mmserver import get_server_url, iid
from utils import log_notice, log_error, make_headers, update_progressbar

socket.setdefaulttimeout(30)
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
dialog = xbmcgui.Dialog()

PATH = 'multimediamaster'
_SERVER_ = get_server_url()

addon = xbmcaddon.Addon()
ADDON_VERSION = addon.getAddonInfo('version')


def switch_skin(skin):
    json_data = {
        'id': 1,
        'jsonrpc': '2.0',
        'method': 'Settings.SetSettingValue',
        'params': {
            'setting': 'lookandfeel.skin',
            'value': skin,
        }
    }

    return xbmc.executeJSONRPC(json.dumps(json_data))


def remove_mm():
    addons_path = xbmc.translatePath(os.path.join('special://home', 'addons'))
    whitelist = ('packages', 'skin.confluence', 'script.module.requests',
                 'plugin.video.multimediamaster', 'repository.multimediamaster')
    to_remove = []

    for match in os.listdir(addons_path):
        if match in whitelist or match.startswith('metadata.'):
            # Skip important directories.
            continue

        to_remove.append(os.path.join(addons_path, match))

    # Switch skin to default one.
    switch_skin('skin.confluence')
    time.sleep(2)

    dp = xbmcgui.DialogProgress()
    dp.create("Maintenance", "Removing MM data folders", ' ', ' ')

    total = len(to_remove)
    for idx, directory in enumerate(to_remove, start=1):
        log_notice('[remove_mm] Removing {0!r}'.format(directory))
        shutil.rmtree(directory, ignore_errors=True)
        update_progressbar(done=idx, total=total, dialog=dp)
        time.sleep(0.05)

    time.sleep(2)
    switch_skin('skin.confluence')
    xbmc.executebuiltin('Quit')


def detect_installed():
    installation_path = addon.getAddonInfo('path')
    addons_path = xbmc.translatePath(os.path.join('special://home', 'addons'))
    common_folders_path = os.path.join(installation_path, 'folders_common.txt')
    mmes_folders_path = os.path.join(installation_path, 'folders_mmes.txt')

    if not os.path.exists(addons_path):
        log_error('[detect] No such folder: {0}!'.format(addons_path))
        return None

    if not os.path.exists(common_folders_path) or not os.path.exists(mmes_folders_path):
        log_error('[detect] Cannot find folders.txt!')
        return None

    common_folders = set()
    mmes_folders = set()

    # Collect common folders needed for detection.
    with open(common_folders_path, 'rt') as f:
        for line in f:
            line = line.strip()
            if line:
                common_folders.add(line)

    # Collect MMES-only folders needed for detection.
    with open(mmes_folders_path, 'rt') as f:
        for line in f:
            line = line.strip()
            if line:
                mmes_folders.add(line)

    # Detect common folders.
    found_common = sum(1 for match in os.listdir(addons_path) if match in common_folders)
    total_common = len(common_folders)

    # Less than 50% of folders present -> broken installation (i.e. nothing installed).
    if float(found_common) / total_common < 0.5:
        return None

    # Detect MMES folders.
    found_mmes = sum(1 for match in os.listdir(addons_path) if match in mmes_folders)
    total_mmes = len(mmes_folders)

    # Less than 50% of MMES folders -> broken installation (i.e. only MM is truly present).
    if float(found_mmes) / total_mmes < 0.5:
        return 'mm'

    # All needed folders found -> MMES.
    return 'mmes'


def categories_when_not_installed():
    add_directory(name='Multimedia Master',
                  url='free',
                  mode='interactive',
                  iconimage=_SERVER_ + 'images/iconfree.png',
                  fanart=_SERVER_ + 'images/fanartfree.jpg',
                  description='Multimedia Master od TechManiacHD, znajdziesz mnie na YouTube')

    add_directory(name='[COLOR=blue]Multimedia[/COLOR] [COLOR=darkorange]Master[/COLOR] [COLOR=darkorange]Edycja[/COLOR] [COLOR=blue]Specjalna[/COLOR]',
                  url='paid',
                  mode='interactive',
                  iconimage=_SERVER_ + 'images/VIPicon.png',
                  fanart=_SERVER_ + 'images/VIPfanart.jpg',
                  description='Multimedia Master od TechManiacHD, znajdziesz mnie na YouTube')

    set_view('movies', 'MAIN')


def categories_for_mm():
    add_directory(name='Remove MM data',
                  url='remove_mm',
                  mode='interactive',
                  iconimage=_SERVER_ + 'images/delete.png',
                  fanart=_SERVER_ + 'images/fanartfree.jpg',
                  description='Remove MM data before downloading MMES')

    set_view('movies', 'MAIN')


def categories_for_mmes():
    add_directory(name='Tapety w wysokiej jakości',
                  url='wallpapers',
                  mode='interactive',
                  iconimage=_SERVER_ + 'images/Wallpapers.png',
                  fanart=_SERVER_ + 'images/VIPfanart.jpg',
                  description='Ta opcja pozwala dograć tapety w wysokiej jakości. Polecane jedynie dla mocnych urządzeń')

    # Updates are only for Kodi 17+
    if _KODI_VERSION > 16:
        add_directory(name='Aktualizacja',
                      url='paid_update',
                      mode='interactive',
                      iconimage=_SERVER_ + 'images/VIPiconupdate.png',
                      fanart=_SERVER_ + 'images/VIPfanartupdate.jpg',
                      description='Aktualizacja')

    for buffer_size in (150, 500, 750):
        add_directory(name='Buffer {0} MB'.format(buffer_size),
                      url='buffer_{0}'.format(buffer_size),
                      mode='interactive',
                      iconimage=_SERVER_ + 'images/RAM.png',
                      fanart=_SERVER_ + 'images/VIPfanart.jpg',
                      description='Buffer {0} MB'.format(buffer_size))

    set_view('movies', 'MAIN')


def show_categories():
    installed_version = detect_installed()
    _iid = iid()
    addon.setSetting(id='build', value=installed_version)
    addon.setSetting(id='iid', value=_iid)

    # At least two thirds of folders should be present.
    if installed_version is None:
        return categories_when_not_installed()

    if installed_version == 'mm':
        return categories_for_mm()

    if installed_version == 'mmes':
        return categories_for_mmes()


def download_build(build_type, password=''):
    path = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
    zip_path = os.path.join(path, build_type + '.zip')

    try:
        os.remove(zip_path)
    except OSError:
        pass

    progress = xbmcgui.DialogProgress()
    progress.create('[I][COLOR=blue]Multimedia[/COLOR] [COLOR=orange]Master[/COLOR][/I]',
                    '[B][COLOR yellow]Krok 1 -[/COLOR][/B] [COLOR violet]Pobieranie pakietu instalacyjnego[/COLOR]', '',
                    '[COLOR lime]Chwilę to potrwa...[/COLOR]')

    if build_type == 'free':
        url = '/download_new.php?type=free&version={v}'.format(
            v=_KODI_VERSION,
        )
    elif build_type == 'paid':
        url = '/download_new.php?type=paid&version={v}&password={p}'.format(
            v=_KODI_VERSION,
            p=password,
        )
    elif build_type == 'paid_update':
        url = '/download_new.php?type=paid&version={v}&password={p}&update=1'.format(
            v=_KODI_VERSION,
            p=password,
        )
    elif build_type == 'wallpapers':
        url = '/download_new.php?type=paid&version={v}&password={p}&wallpapers=1'.format(
            v=_KODI_VERSION,
            p=password,
        )
    elif build_type.startswith('buffer_'):
        buffer_size = build_type.replace('buffer_', '')
        url = '/download_new.php?type=paid&version={v}&password={p}&buffer={buffer}'.format(
            v=_KODI_VERSION,
            p=password,
            buffer=buffer_size,
        )
    else:
        # Unknown type
        return None

    try:
        downloader.download(url=_SERVER_ + url, dest=zip_path, dp=progress)
    except Exception as ex:
        progress.close()
        xbmcgui.Dialog().ok('Wystąpił błąd', ex.message)
        return

    addonfolder = xbmc.translatePath(os.path.join('special://', 'home'))

    # Wait a bit.
    time.sleep(2)

    progress.update(0, '[B][COLOR yellow]Krok 2 -[/COLOR][/B] [COLOR violet]Wypakowywanie pobranego pakietu[/COLOR]')
    print '======================================='
    print addonfolder
    print '======================================='
    extract.extract_all(zip_path, addonfolder, progress)

    killxbmc()


def killxbmc():
    choice = xbmcgui.Dialog().yesno('[COLOR lime]ZAKOŃCZONO :)[/COLOR]', 'Jedynym sposobem by Kodi przyjął nakladkę jest [COLOR red]wymuszenie zamknięcia.[/COLOR]', nolabel='Anuluj',yeslabel='Wymuś')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = current_platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA  !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie [COLOR=lime]NIE[/COLOR] zamykaj kodi poprzez przycisk w menu!",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA  !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie [COLOR=lime]NIE[/COLOR] zamykaj kodi poprzez przycisk w menu!",'')
    elif myplatform == 'android': # Android
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA !!![/COLOR][/B]", "Twój system został wykryty jako [COLOR green]Android[/COLOR], ", "[COLOR=yellow][B]NALEŻY[/COLOR][/B] wymusić zamknięcie Kodi. [COLOR=green]OPCJA 1:[/COLOR] Przejdź do kart ostatich aplikacji i zamknij Kodi (przeciągnij z listy). [COLOR=green]OPCJA 2:[/COLOR] Przejdź do managera zadań by wymusić zamknięcie Kodi. [COLOR=green]OPCJA 3:[/COLOR] Zwyczajnie zrestartuj urządzenie",'')
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie. [COLOR=lime]NIE[/COLOR] zamykaj Kodi poprzez przycisk w menu!","Wciśnij lewy Ctrl+Shift+ESC, pokaż więcej szczegółów, w procesach odnajdź KODI i zakończ to zadanie i uruchom Kodi ponownie")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie. [COLOR=lime]NIE[/COLOR] zamykaj Kodi poprzez przycisk w menu!","Twoja platforma nie mogła być wykryta, po prostu odłącz zasilanie i uruchom Kodi ponownie")


def current_platform():
    cmds = ('system.platform.android', 'system.platform.linux', 'system.platform.windows',
            'system.platform.osx', 'system.platform.atv2', 'system.platform.ios')

    for cmd in cmds:
        if xbmc.getCondVisibility(cmd):
            return cmd.split('.')[-1]

    raise RuntimeError('Unknown platform')


def add_directory(name, url, mode, iconimage, fanart, description):
    u = '{bin}?url={url}&mode={mode}&name={name}&iconimage={icon}&fanart={fanart}&description={desc}'.format(
        bin=sys.argv[0],
        url=quote_plus(url),
        mode=quote_plus(mode),
        name=quote_plus(name),
        icon=quote_plus(iconimage),
        fanart=quote_plus(fanart),
        desc=quote_plus(description),
    )

    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
    liz.setProperty('Fanart_Image', fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


def get_params():
    query_string = sys.argv[2].replace('?', '')
    params = defaultdict(lambda: '')
    for k, v in parse_qsl(query_string, keep_blank_values=True):
        params[k] = v

    return params


def set_view(content, view_type):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.getSetting('auto-view') == 'true':
        xbmc.executebuiltin('Container.SetViewMode(%s)' % addon.getSetting(view_type))


def get_password():
    password = addon.getSetting(id='paid')
    if password:
        return password

    keyboard = xbmc.Keyboard('', 'Wprowadź klucz instalacyjny', False)
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return None

    text = keyboard.getText()
    if not text:
        return None

    url = '/download_new.php?type=paid&version={v}&password={t}&check=1'.format(
        v=_KODI_VERSION,
        t=text,
    )

    r = requests.get(url=_SERVER_ + url, headers=make_headers())
    if r.headers['Content-Type'] == 'application/json':
        error_data = json.loads(r.text)
        dialog.ok('Wystąpił błąd', error_data.get('message', '<UNKNOWN>'))
        return None
    else:
        addon.setSetting(id='paid', value=text)
        return text


def process_parameters(p):
    if p['url'].startswith('buffer_'):
        password = get_password()
        if not password:
            return None

        return download_build(build_type=p['url'], password=password)

    if p['url'] == 'remove_mm':
        return remove_mm()

    if p['url'] == 'free':
        return download_build(build_type='free')

    if p['url'] == 'paid':
        password = get_password()
        if not password:
            return None

        return download_build(build_type='paid', password=password)

    if p['url'] == 'paid_update':
        password = get_password()
        if not password:
            return None

        return download_build(build_type='paid_update', password=password)

    if p['url'] == 'wallpapers':
        password = get_password()
        if not password:
            return None

        return download_build(build_type='wallpapers', password=password)


def plugin_main():
    params = get_params()

    print str(PATH) + ': ' + str(ADDON_VERSION)
    print 'Mode: ' + params['mode']
    print 'URL: ' + params['url']
    print 'Name: ' + params['name']
    print 'IconImage: ' + params['iconimage']

    if not params['mode'] or not params['url'] or len(params['url']) < 1:
        show_categories()
    else:
        process_parameters(params)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


plugin_main()
