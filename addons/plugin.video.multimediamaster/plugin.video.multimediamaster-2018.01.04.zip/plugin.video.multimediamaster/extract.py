import os
import zipfile
from utils import log_notice, log_error


def extract_all(_in, _out, dp=None):
    if dp:
        return all_with_progress(_in, _out, dp)

    return all_no_progress(_in, _out)


def all_no_progress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False

    return True


def log_progress(dp, percent, errors):
    if not errors:
        return dp.update(percent)

    return dp.update(percent, line2='%d errors skipped' % errors)


def all_with_progress(_in, _out, dp):
    zin = zipfile.ZipFile(_in, 'r')

    percent = 0
    previous_percent = 0

    items = zin.infolist()
    total = len(items)

    errors = 0
    ignore_files = {'.gitignore'}

    try:
        for count, item in enumerate(items, start=1):
            if os.path.split(item.filename)[-1] in ignore_files:
                continue

            try:
                zin.extract(item, _out)
            except (IOError, OSError) as e:
                log_error('[E] Error at {percent:.1f}%: {ex!s}'.format(percent=percent, ex=e))
                errors += 1

            percent = int(count * 100.0 / total)
            if previous_percent != percent:
                previous_percent = percent
                if percent % 10 == 0:
                    log_notice('[E] Extracted {0}% so far...'.format(percent))
                log_progress(dp, percent, errors)
    except Exception, e:
        log_error('[E] Error at {percent:.1f}%: {ex!s}'.format(percent=percent, ex=e))
        return False
    else:
        log_notice('[E] Extraction finished! {0} files extracted [{1} errors]'.format(total, errors))
        return True
