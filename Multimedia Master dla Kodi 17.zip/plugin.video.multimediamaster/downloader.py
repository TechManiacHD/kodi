# coding: utf-8
from __future__ import print_function
import json
import requests
import socket
import time

from collections import deque
from hashlib import sha1

import xbmcgui

from utils import log_notice, log_error, make_headers, readable_size
from kodi_version import _KODI_VERSION

TIMEOUT = 10
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

socket.setdefaulttimeout(TIMEOUT)


def download(url, dest, dp=None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create("SimpleKodi...Maintenance", "Downloading & Copying File", ' ', ' ')
    dp.update(0)

    headers = {'Accept': '*/*', 'Accept-Encoding': 'identity'}
    headers.update(make_headers())

    bytes_downloaded = 0
    bytes_total = 0
    max_attempts = 30

    previous_percent = 0

    # Hashing received data to ensure correct downloads.
    digest = sha1()

    # A collection for speed reporting.
    speeds = deque(maxlen=10)

    log_notice('[D] Download {0!r} to {1!r}'.format(url, dest))
    with open(dest, 'wb') as f:
        for attempt in range(1, max_attempts + 1):
            try:
                # If something is already downloaded, then we must provide
                # a "Range" header to the server.
                if bytes_downloaded != 0:
                    h = {'Range': 'bytes={0}-'.format(bytes_downloaded)}
                    headers.update(h)

                # Create a request with chosen settings.
                r = requests.get(url, stream=True, timeout=(TIMEOUT, TIMEOUT), headers=headers)

                # Check if it's not a zip, but an error message instead.
                if r.headers['Content-Type'] == 'application/json':
                    # Get error description.
                    error_data = json.loads(r.text)

                    # Close the connection.
                    r.close()

                    raise Exception(error_data.get('message', '<UNKNOWN>'))

                # Content-Length shows the total download size ONLY if it's the first attempt.
                if not bytes_total:
                    bytes_total = int(r.headers.get('content-length'))

                # Pretend that the previous report is now -- the first byte of a download.
                previous_report_time = time.time()

                # Iterate over received data, update the progress and write it to file.
                for chunk in r.iter_content(chunk_size=256 * 1024):
                    if not chunk:
                        continue

                    # Update the hash.
                    digest.update(chunk)

                    # Write data to disk.
                    f.write(chunk)

                    # Update percentages.
                    bytes_downloaded += len(chunk)
                    try:
                        percent = int(bytes_downloaded * 100.0 / bytes_total)
                    except ZeroDivisionError:
                        percent = 100

                    # Don't report anything if percentage didn't change,
                    # that would be too often.
                    if previous_percent == percent:
                        continue

                    previous_percent = percent
                    if percent % 10 == 0:
                        log_notice('[D] Downloaded {0}% so far...'.format(percent))

                    # Calculate time elapsed from a previous progressbar update.
                    # Use this time to calculate current speed, and later average speed.
                    now = time.time()
                    try:
                        current_speed = (bytes_total / 100.0) / (now - previous_report_time)
                    except ZeroDivisionError:
                        current_speed = 0.0

                    previous_report_time = now

                    speeds.append(current_speed)
                    average_speed = readable_size(float(sum(speeds)) / len(speeds), bits=True) + 'it/s'

                    # Do an actual progressbar update.
                    message = create_report(percentage=percent,
                                            total_size=bytes_total,
                                            downloaded=bytes_downloaded,
                                            speed=average_speed)
                    update_progressbar(percent, '\n\n\n', dialog=dp)
                    update_progressbar(percent, message, dialog=dp)

                # Everything is finished!
                if bytes_downloaded == bytes_total:
                    r.close()
                    break
            except requests.exceptions.ConnectionError:
                log_notice('[D] [attempt #{0}] Connection error, retrying...'.format(attempt))
            except requests.exceptions.Timeout:
                log_notice('[D] [attempt #{0}] Timeout reached, retrying...'.format(attempt))
            except requests.exceptions.ChunkedEncodingError:
                log_notice('[D] [attempt #{0}] Got malformed data, retrying...'.format(attempt))
            except socket.timeout:
                log_notice('[D] [attempt #{0}] Socket timeout, retrying...'.format(attempt))

            sleep_time = attempt / 5 + 1
            time.sleep(sleep_time)
        else:
            log_error('[D] Could not download the file after {0} attempts!'.format(max_attempts))
            raise Exception('Nieudane pobieranie!')

    try:
        done_percent = bytes_downloaded * 100.0 / bytes_total
    except ZeroDivisionError:
        done_percent = 100.0

    log_notice('[D] Download finished! {0:.2f}%, {1} bytes downloaded. SHA1 hash: {2}'.format(
        done_percent, bytes_downloaded, digest.hexdigest(),
    ))

    # Update with an empty message to clear everything.
    update_progressbar(100, message='\n\n\n', dialog=dp)


def update_progressbar(percentage, message, dialog):
    dialog.update(percentage, message)

    if dialog.iscanceled():
        dialog.close()
        raise Exception("Canceled")


def create_report(percentage, total_size, downloaded, speed):
    if _KODI_VERSION > 16:
        fmt = '[COLOR=lime]Pobrano[/COLOR] {d} [COLOR=lime]z[/COLOR] {t} ({perc}%)\n[COLOR=lime]Bieżąca prędkość[/COLOR] {sp}'
    else:
        fmt = '[COLOR=lime]Pobrano[/COLOR] {d} [COLOR=lime]z[/COLOR] {t}\n[COLOR=lime]Bieżąca prędkość[/COLOR] {sp}'

    return fmt.format(
        perc=percentage,
        d=readable_size(downloaded),
        t=readable_size(total_size),
        sp=speed,
    )
