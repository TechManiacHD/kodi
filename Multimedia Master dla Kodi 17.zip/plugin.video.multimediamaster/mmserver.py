# coding: UTF-8
import sys
l1_zZZzZZZzzZzz_ = sys.version_info [0] == 2
l11_zZZzZZZzzZzz_ = 2048
l1l11_zZZzZZZzzZzz_ = 7
def l1lll_zZZzZZZzzZzz_ (ll_zZZzZZZzzZzz_):
    global l1l_zZZzZZZzzZzz_
    l1l1l_zZZzZZZzzZzz_ = ord (ll_zZZzZZZzzZzz_ [-1])
    l1ll1_zZZzZZZzzZzz_ = ll_zZZzZZZzzZzz_ [:-1]
    l1l1_zZZzZZZzzZzz_ = l1l1l_zZZzZZZzzZzz_ % len (l1ll1_zZZzZZZzzZzz_)
    l11l_zZZzZZZzzZzz_ = l1ll1_zZZzZZZzzZzz_ [:l1l1_zZZzZZZzzZzz_] + l1ll1_zZZzZZZzzZzz_ [l1l1_zZZzZZZzzZzz_:]
    if l1_zZZzZZZzzZzz_:
        l1ll_zZZzZZZzzZzz_ = unicode () .join ([unichr (ord (char) - l11_zZZzZZZzzZzz_ - (l111_zZZzZZZzzZzz_ + l1l1l_zZZzZZZzzZzz_) % l1l11_zZZzZZZzzZzz_) for l111_zZZzZZZzzZzz_, char in enumerate (l11l_zZZzZZZzzZzz_)])
    else:
        l1ll_zZZzZZZzzZzz_ = str () .join ([chr (ord (char) - l11_zZZzZZZzzZzz_ - (l111_zZZzZZZzzZzz_ + l1l1l_zZZzZZZzzZzz_) % l1l11_zZZzZZZzzZzz_) for l111_zZZzZZZzzZzz_, char in enumerate (l11l_zZZzZZZzzZzz_)])
    return eval (l1ll_zZZzZZZzzZzz_)
import zlib, base64
exec(zlib.decompress(base64.b64decode(l1lll_zZZzZZZzzZzz_ (u"ࠫࡪࡐࡹࡏ࡭ࡇ࠵ࡷࡽࡺࡂࡓࡔࡔ࡫࠾ࡩ࡮ࡺࡒࡻࡒ࡚࠶࠹ࡇ࡯࡛ࡼࡌࡶ࡙࡬ࡴ࡛࡯ࡻ࡚ࡏࡑࡶࡧࡋࡕࡪࡌࡍ࠳࡬࡟ࡊ࠯࠴ࡰࡕࡽࡵࡻࡌ࠲࠵࡭࠶࠹ࡪ࠴ࡉ࡬࠼ࡷࡘ࠻ࡵ࠴ࡎ࠹࠸ࡹ࡚ࡤ࠱ࡴ࡭ࡦࡍࢀࡦࡣࡕࡽࡴ࠾ࡼࡂࡇ࠭࠲ࡶࡾ࠹ࡒ࡛࠱ࡽࡪࡐࡿࡱ࠵࡯ࡘ࠺ࡹ࠶ࡖ࡮࠵࠳࠽࠹ࡎࡧ࠸ࡨࡗࡓࡊࡽࡪ࠷࠻࠷࠯ࡇ࠵࠳ࡣࡖࡋࡨࡽࡰࡸࡎࡊࡄࡥࡨ࠾ࡊࡰ࠷ࡓ࡜ࡍ࡯ࡦࡆࡸࡱࡦ࡝ࡎࡶࡅࡌࡅ࠷ࡌࡰࡒࡊࡣࡇࡗ࡬࡭ࠫࡃࡆࡦࡏ࡞࡮࠱ࡎࡌࡊ࡛࠴ࡻࡡࡢࡪࡰࡴ࡫ࡺࡷ࠸ࡆ࠺࡞ࡌࡷ࠴ࡸࡊ࠳ࡉࡏࡶࡢࡕࡺࡤࡅ࠵ࡿࡒࡑࡍࡅ࡫ࡴࡧࡸࡖࡱࡧࡦ࠽ࡷࡏ࠷ࡦࡇ࡙ࡶࡿࡒࡊࡘࡤࡅࡵࡵ࡭ࡘࡷࡰ࡭࡟ࡩࡆࡊࡇࡳ࠶ࡵࡐࡑࡌࡌࡲࡅࡉ࠵ࡤ࡫࠳ࡍࡅࡩࡵࡊࡓ࠻ࡕࡉ࡞࡚࠱ࡅࡃ࠼ࡋࡘ࡟ࡓࡆ࡫࠳࠽ࡓࡗࡖ࡬ࡓࡇ࠽ࡱࡋࡖࡩ࠵࡫ࡎࡊ࠱ࡢࡥ࠸ࡵࡔࡧ࠻ࡢ࡯࡮࠹ࡳࡇࡌ࡭ࡴࡸ࡙ࡎ࡞ࡹ࠰࡭ࡍࡸࡘࡋࡷ࡫ࡷ࠻࠸ࡸ࡫ࡖ࡯ࠬ࡮ࡓࡻࡂࡃࠧࠀ"))))