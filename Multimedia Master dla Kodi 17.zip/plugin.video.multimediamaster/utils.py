# coding: utf-8
from functools import partial
import xbmc
import xbmcaddon
from kodi_version import KODI_VERSION

ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')


def update_progressbar(total, done, dialog):
    percentage = int(done * 100.0 / total)
    fmt = 'Deleted {d} folders out of {t} ({perc}%)'
    message = fmt.format(
        perc=percentage,
        d=done,
        t=total,
    )

    dialog.update(percentage, '\n\n\n')
    dialog.update(percentage, message)
    if dialog.iscanceled():
        dialog.close()
        raise Exception("Canceled")


def readable_size(size, bits=False):
    """
    Convert size in bytes to a readable representation.
    Example: 9793242 -> '9.3 MB'
    :param size: Size in the smallest unit.
    :param bits: Whether to use bits instead of bytes for the result.
    :return: Human-readable representation of a size.
    """
    if bits:
        size *= 8

    for unit in ('', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB'):
        if size < 1000.0:
            return '{s:.2f} {u}'.format(s=size, u=unit)
        size /= 1000.0

    return '???'


def _log(message, level):
    """
    Output a `message` to a Kodi log file with desired verbosity `level`.
    """
    xbmc.log('[{addon_version} @ K{kodi_version}] {message}'.format(
        addon_version=ADDON_VERSION,
        kodi_version=KODI_VERSION,
        message=message,
    ), level)


# Convenient shortcuts for specific verbosity levels.
log_notice = partial(_log, level=xbmc.LOGNOTICE)
log_error = partial(_log, level=xbmc.LOGERROR)
