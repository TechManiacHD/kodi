import xbmc
import zipfile


def extract_all(_in, _out, dp=None):
    if dp:
        return all_with_progress(_in, _out, dp)

    return all_no_progress(_in, _out)


def all_no_progress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False

    return True


def all_with_progress(_in, _out, dp):
    zin = zipfile.ZipFile(_in, 'r')

    previous_percent = 0
    items = zin.infolist()
    total = len(items)

    try:
        for count, item in enumerate(items, start=1):
            zin.extract(item, _out)
            percent = int(count * 100.0 / total)
            if previous_percent != percent:
                previous_percent = percent
                if percent % 10 == 0:
                    xbmc.log('[extract] Extracted {0}% so far...'.format(percent), xbmc.LOGNOTICE)
                dp.update(percent)
    except Exception, e:
        xbmc.log('[extract] Error at {percent:.1f}%: {ex!s}'.format(percent=update, ex=e), xbmc.LOGERROR)
        return False

    return True
